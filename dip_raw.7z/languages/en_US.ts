<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>ACEDialog</name>
    <message>
        <location filename="../acedialog.cpp" line="49"/>
        <source>Filter Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../acedialog.cpp" line="62"/>
        <source>MAX CG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../acedialog.cpp" line="74"/>
        <source>Gain Coef</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../acedialog.cpp" line="95"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../acedialog.cpp" line="96"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../acedialog.cpp" line="97"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EmbossFilterDialog</name>
    <message>
        <location filename="../embossfilterdialog.cpp" line="211"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../embossfilterdialog.cpp" line="212"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../embossfilterdialog.cpp" line="213"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FDFilterDialog</name>
    <message>
        <location filename="../fdfilterdialog.cpp" line="59"/>
        <source>Filter Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fdfilterdialog.cpp" line="62"/>
        <source>ideal low pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fdfilterdialog.cpp" line="63"/>
        <source>ideal high pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fdfilterdialog.cpp" line="64"/>
        <source>Gaussian low pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fdfilterdialog.cpp" line="65"/>
        <source>Butterworth low pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fdfilterdialog.cpp" line="66"/>
        <source>Butterworth high pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fdfilterdialog.cpp" line="69"/>
        <source>Filter Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fdfilterdialog.cpp" line="85"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fdfilterdialog.cpp" line="86"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fdfilterdialog.cpp" line="87"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="71"/>
        <source>DIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="123"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="131"/>
        <location filename="../mainwindow.cpp" line="238"/>
        <source>Image loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="223"/>
        <location filename="../mainwindow.cpp" line="339"/>
        <source>&amp;%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="246"/>
        <location filename="../mainwindow.cpp" line="253"/>
        <source>File saved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="284"/>
        <source>About DIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="285"/>
        <source>The &lt;b&gt;DIP&lt;/b&gt; demonstrates Digital Image Processing using Qt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="342"/>
        <source>%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="367"/>
        <location filename="../mainwindow.cpp" line="1014"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="368"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="371"/>
        <location filename="../mainwindow.cpp" line="1016"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="373"/>
        <location filename="../mainwindow.cpp" line="1017"/>
        <source>Create a new file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="379"/>
        <location filename="../mainwindow.cpp" line="1019"/>
        <source>&amp;Open...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="381"/>
        <location filename="../mainwindow.cpp" line="1020"/>
        <source>Open an existing file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="387"/>
        <location filename="../mainwindow.cpp" line="1022"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="1023"/>
        <source>Save the document to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="394"/>
        <location filename="../mainwindow.cpp" line="1025"/>
        <source>Save &amp;As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="396"/>
        <location filename="../mainwindow.cpp" line="1026"/>
        <source>Save the document under a new name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="402"/>
        <location filename="../mainwindow.cpp" line="1028"/>
        <source>Recent...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="415"/>
        <location filename="../mainwindow.cpp" line="1030"/>
        <source>Switch layout direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="421"/>
        <location filename="../mainwindow.cpp" line="1032"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="423"/>
        <location filename="../mainwindow.cpp" line="1033"/>
        <source>Exit the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="428"/>
        <location filename="../mainwindow.cpp" line="1034"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="429"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="432"/>
        <location filename="../mainwindow.cpp" line="1037"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="434"/>
        <location filename="../mainwindow.cpp" line="1038"/>
        <source>Copy the current selection&apos;s contents to the clipboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="441"/>
        <location filename="../mainwindow.cpp" line="1041"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="443"/>
        <location filename="../mainwindow.cpp" line="1042"/>
        <source>Paste the clipboard&apos;s contents into the current selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="450"/>
        <location filename="../mainwindow.cpp" line="1045"/>
        <source>&amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="453"/>
        <location filename="../mainwindow.cpp" line="1047"/>
        <source>Cl&amp;ose</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="454"/>
        <location filename="../mainwindow.cpp" line="1048"/>
        <source>Close the active window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="458"/>
        <location filename="../mainwindow.cpp" line="1050"/>
        <source>Close &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="459"/>
        <location filename="../mainwindow.cpp" line="1051"/>
        <source>Close all the windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="462"/>
        <location filename="../mainwindow.cpp" line="1053"/>
        <source>&amp;Switch View Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="463"/>
        <location filename="../mainwindow.cpp" line="1054"/>
        <source>Switch View Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="466"/>
        <location filename="../mainwindow.cpp" line="1056"/>
        <source>&amp;Tile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="467"/>
        <location filename="../mainwindow.cpp" line="1057"/>
        <source>Tile the windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="470"/>
        <location filename="../mainwindow.cpp" line="1059"/>
        <source>&amp;Cascade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="471"/>
        <location filename="../mainwindow.cpp" line="1060"/>
        <source>Cascade the windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="474"/>
        <location filename="../mainwindow.cpp" line="1062"/>
        <source>Ne&amp;xt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="476"/>
        <location filename="../mainwindow.cpp" line="1063"/>
        <source>Move the focus to the next window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="479"/>
        <location filename="../mainwindow.cpp" line="1065"/>
        <source>Pre&amp;vious</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="481"/>
        <location filename="../mainwindow.cpp" line="1066"/>
        <source>Move the focus to the previous window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="492"/>
        <location filename="../mainwindow.cpp" line="1069"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="495"/>
        <location filename="../mainwindow.cpp" line="1070"/>
        <source>Zoom &amp;In (25%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="499"/>
        <location filename="../mainwindow.cpp" line="1071"/>
        <source>Zoom &amp;Out (25%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="503"/>
        <location filename="../mainwindow.cpp" line="1072"/>
        <source>&amp;Normal Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="504"/>
        <location filename="../mainwindow.cpp" line="1073"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="509"/>
        <location filename="../mainwindow.cpp" line="1074"/>
        <source>&amp;Fit to Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="512"/>
        <location filename="../mainwindow.cpp" line="1075"/>
        <source>Ctrl+F</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="523"/>
        <location filename="../mainwindow.cpp" line="559"/>
        <location filename="../mainwindow.cpp" line="1076"/>
        <location filename="../mainwindow.cpp" line="1097"/>
        <source>Gray Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="524"/>
        <location filename="../mainwindow.cpp" line="1077"/>
        <source>Spectrum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="525"/>
        <location filename="../mainwindow.cpp" line="1079"/>
        <source>Histogram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="526"/>
        <location filename="../mainwindow.cpp" line="1080"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="527"/>
        <location filename="../mainwindow.cpp" line="540"/>
        <location filename="../mainwindow.cpp" line="1081"/>
        <location filename="../mainwindow.cpp" line="1087"/>
        <source>R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="528"/>
        <location filename="../mainwindow.cpp" line="541"/>
        <location filename="../mainwindow.cpp" line="1082"/>
        <location filename="../mainwindow.cpp" line="1088"/>
        <source>G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="529"/>
        <location filename="../mainwindow.cpp" line="542"/>
        <location filename="../mainwindow.cpp" line="1083"/>
        <location filename="../mainwindow.cpp" line="1089"/>
        <source>B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="532"/>
        <location filename="../mainwindow.cpp" line="1085"/>
        <source>Negative</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="539"/>
        <location filename="../mainwindow.cpp" line="1086"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="545"/>
        <location filename="../mainwindow.cpp" line="1091"/>
        <source>PseudoColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="552"/>
        <location filename="../mainwindow.cpp" line="1092"/>
        <source>Jet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="553"/>
        <location filename="../mainwindow.cpp" line="1093"/>
        <source>Parula</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="554"/>
        <location filename="../mainwindow.cpp" line="1094"/>
        <source>Hot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="558"/>
        <location filename="../mainwindow.cpp" line="1096"/>
        <source>&amp;Enhancement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="560"/>
        <location filename="../mainwindow.cpp" line="1098"/>
        <source>Hist Equalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="561"/>
        <location filename="../mainwindow.cpp" line="1099"/>
        <source>Adaptive Contrast Equalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="564"/>
        <location filename="../mainwindow.cpp" line="1101"/>
        <source>&amp;Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="565"/>
        <location filename="../mainwindow.cpp" line="1102"/>
        <source>Space Domain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="566"/>
        <location filename="../mainwindow.cpp" line="1103"/>
        <source>Frequency Domain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="567"/>
        <location filename="../mainwindow.cpp" line="1104"/>
        <source>Emboss Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="571"/>
        <location filename="../mainwindow.cpp" line="1106"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="573"/>
        <location filename="../mainwindow.cpp" line="1107"/>
        <source>&amp;Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="575"/>
        <location filename="../mainwindow.cpp" line="1108"/>
        <source>&amp;Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="580"/>
        <location filename="../mainwindow.cpp" line="1109"/>
        <source>&amp;English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="584"/>
        <location filename="../mainwindow.cpp" line="1111"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="585"/>
        <location filename="../mainwindow.cpp" line="1112"/>
        <source>Show the application&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="587"/>
        <location filename="../mainwindow.cpp" line="1114"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="588"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <source>Show the Qt library&apos;s About box</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="593"/>
        <source>Ready</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="968"/>
        <source>Frequency Domain Filtering</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="987"/>
        <source>Emboss Filtering</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MdiChild</name>
    <message>
        <location filename="../mdichild.cpp" line="76"/>
        <source>image%1.jpg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mdichild.cpp" line="90"/>
        <source>Cannot load %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mdichild.cpp" line="134"/>
        <source>Save As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mdichild.cpp" line="149"/>
        <source>Cannot write %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mdichild.cpp" line="185"/>
        <source>DIP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mdichild.cpp" line="186"/>
        <source>&apos;%1&apos; has been modified.
Do you want to save your changes?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SDFilterDialog</name>
    <message>
        <location filename="../sdfilterdialog.cpp" line="314"/>
        <source>Original</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="317"/>
        <source>Roberts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="320"/>
        <source>Sobel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="323"/>
        <source>Prewitt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="326"/>
        <source>Laplacian4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="329"/>
        <source>Laplacian8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="332"/>
        <source>LOG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="336"/>
        <source>Border</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="339"/>
        <source>replicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="340"/>
        <source>reflect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="341"/>
        <source>reflect101</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="342"/>
        <source>wrap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="343"/>
        <source>zero padding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="346"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="378"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="379"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sdfilterdialog.cpp" line="380"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
