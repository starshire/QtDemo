#include "mdiviewchild.h"

MdiViewChild::MdiViewChild(MdiChild *parent)
{
    this->owner = parent;
}
